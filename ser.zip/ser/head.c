﻿#include "head.h"

linklist init_list()
{
	linklist head = malloc(sizeof(listnode));
	if(head == NULL)
	{
		perror("head:");
		exit(0);
	}
	bzero(head, sizeof(listnode));
	head->next = head;
	head->prev = head;
	head->tcp_socket = 0;
	return head;
	
}

void list_add(linklist head, struct sockaddr_in *new_addr,int tcp_socket)
{
	linklist tmp = head;
	linklist new_node = malloc(sizeof(listnode));
	if(new_node == NULL)
	{
		perror("new_node:");
		exit(0);
	}
	bzero(new_node, sizeof(listnode));
	new_node->addr.sin_family = new_addr->sin_family;
	new_node->addr.sin_port = new_addr->sin_port;
	new_node->addr.sin_addr.s_addr = new_addr->sin_addr.s_addr;	
	new_node->tcp_socket = tcp_socket;
	new_node->talk = 0;
	new_node->other = 0;
	new_node->down_file = 0;
	new_node->up_file = 0;
	while(tmp->next != head)
		tmp = tmp->next;
	new_node->next = head;
	head->prev = new_node;
	new_node->prev = tmp;
	tmp->next = new_node;
	
}

void list_del(linklist pos)
{

				
				linklist del = pos;
				del->prev->next = del->next;  
				del->next->prev = del->prev;  
				del->next = NULL; 
				del->prev = NULL;  
				close(del->tcp_socket);
				free(del);

}

void *weather(void *arg)	//获取天气
{
	pthread_detach(pthread_self()); //设置自己的分离属性
	linklist tmp = (linklist)arg; 
	int net_socket = socket(AF_INET, SOCK_STREAM, 0);
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(80);
	addr.sin_addr.s_addr = inet_addr("47.107.155.132");
	int ret = connect(net_socket, (struct sockaddr *)&addr, sizeof(addr));
	if(ret < 0)
	{
		perror("");
		return 0;
	}
	printf("success\n");
	
	char *http = "GET /api.php?key=free&appid=0&msg=天气广州 HTTP/1.1\r\nHost:api.qingyunke.com\r\n\r\n";
	write(net_socket, http, strlen(http));
	
	char buf1[4096];
	read(net_socket, buf1, 4096);
	char *head_end = strstr(buf1,"\r\n\r\n")+4;
	//printf("%s\n",buf1);
	write(tmp->tcp_socket, head_end, strlen(head_end));
	
	close(net_socket);
}

void *recvfile(void *arg)	//接收文件
{
	pthread_detach(pthread_self());
	linklist pos = (linklist)arg;
	char head[4096] = {0};
	
	
	
	
	int size = read(pos->tcp_socket, head, sizeof(head));
	//head 定义为 file_name:文件名字\r\nContent_length:文件大小\r\n\r\n文件内容
	
	if(strcmp(head, "exit") == 0)
	{
		printf("退出接收文件\n");
	}
	else
	{
			
			char buf[4096] = {0};
			char buf1[1024] = {0};
			char buf2[1024] = {0};
			char file_name[100] = {0};
			sscanf(head,"file_name:%s\r\nContent_length:%s\r\n\r\n%s",buf1, buf2, buf);
			
			strcpy(file_name, buf1);
			int Content_length = atoi(buf2);
			printf("file_size:%d\n",Content_length);
			
			int fd = open(file_name,O_CREAT|O_RDWR, 0777);
			if(fd < 0)
			{
				perror("接收文件失败");
				pos->up_file = 0;
				return 0;
			}
			char *end = strstr(head,"\r\n\r\n")+4;
			write(fd, end, size-(int)(end-head));
			int down_size = size-(int)(end-head);
			while(1)
			{
				char buf[4096] = {0};
				size = read( pos->tcp_socket,buf, 4096);
				write(fd,buf ,size);
				down_size += size;
				if(down_size == Content_length)
				{
					printf("传输完毕\n");
					break;
				}
			}
			close(fd);
	}
	pos->up_file = 0;
}

void *sendfile(void *arg)  //发送文件
{
	pthread_detach(pthread_self());
	linklist pos = (linklist)arg;
	char name[100];
	read(pos->tcp_socket, name, 100);
	
	if(strcmp(name, "exit") == 0)
	{
		printf("退出接收文件\n");
	}
	else
	{
			int fd = open(name, O_RDWR);
			if(fd < 0)
			{
				printf("fd is error\n");
			}
			else
			{
				char buf[1024] = {0};
				printf("%s\n",name);
				int size = lseek(fd, 0, SEEK_END);
				lseek(fd, 0, SEEK_SET);
				sprintf(buf,"file_name:%s\r\nContent_length:%d\r\n\r\n",name,size);
				write(pos->tcp_socket, buf, strlen(buf));
				while(1)
				{
					char file_buf[4096] = {0};
					size = read(fd, file_buf, 4096);
					if(size == 0)
					{
						printf("上传完毕\n");
						close(fd);
						break;
					}
					write(pos->tcp_socket, file_buf, size);
				}
			
				close(fd);
			}
	}
	pos->down_file = 0;
}
