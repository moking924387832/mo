﻿#ifndef __HEAD_H_
#define __HEAD_H_

#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> /* superset of previous */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h> 
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <fcntl.h>
#include <stdlib.h>
#include <dirent.h>

#define IP_ADDRESS "192.168.22.133" //服务器的ip地址  
#define PORT_NUMBER 7777	//服务器的端口号

typedef struct node
{
	struct sockaddr_in addr;
	int tcp_socket;
	int talk;		//是否聊天
	int other;		//选择聊天对象
	int down_file;		//客服是否下载文件
	int up_file;		//客服是否上传文件
	struct node *next;
	struct node *prev;
}listnode, *linklist;

linklist init_list();
void list_add(linklist head, struct sockaddr_in *new_addr,int tcp_socket);
void list_del(linklist pos);
void *weather(void *arg);	//获取天气
void *recvfile(void *arg);	//接收文件
void *sendfile(void *arg);  //发送文件


#endif