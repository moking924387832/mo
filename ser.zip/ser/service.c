﻿#include "head.h"


int main()
{
	int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(tcp_socket < 0)
	{
		perror("tcp_socket:");
		return 0;
	}
		//解决端口复用
	int on=1;
	setsockopt(tcp_socket,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(on));
	on=1;
	setsockopt(tcp_socket,SOL_SOCKET,SO_REUSEPORT,&on,sizeof(on));
	
	
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_port = htons(PORT_NUMBER);
	addr.sin_addr.s_addr = inet_addr(IP_ADDRESS);
	int ret = bind(tcp_socket, (struct sockaddr *)&addr, sizeof(addr));
	if(ret < 0)
	{
		perror("bind");
		return 0;
	}
	listen(tcp_socket, 5);
	
	
	//创建链表
	linklist head = init_list();
	int max=0;
	char *announcement = malloc(4096);
	 while(1)
	 {
			int sum=0; //总的用户数
			 //1.清空文件描述符集合 
		   fd_set set;
		   FD_ZERO(&set);
		
		 //2.把需要监听文件描述符 添加到集合中 
		  FD_SET(0,&set);
		
		
		 //3.把服务器文件描述符添加到集合中 
		  FD_SET(tcp_socket,&set);
		  
		  for(linklist tmp = head->next;tmp != head;tmp=tmp->next)
		 {
			FD_SET(tmp->tcp_socket,&set); 
			sum++;
		 }
		  
		  if(max == 0)
		  {
			max = tcp_socket;
		  }
		  else
		  {
			for(linklist tmp = head->next; tmp != head; tmp = tmp->next)
			{
				
				if(max < tmp->tcp_socket)
				{
					max = tmp->tcp_socket;
				}
			}
		
		  }
		  
		  int ret=select(max+1,&set,NULL,NULL,NULL);
		  if(ret < 0)
		  {
			   perror("select:");
			   return 0; 
		  }
		
		
		
		
		
		  if(FD_ISSET(tcp_socket,&set)) //查看有无链接
		{
		
			struct sockaddr_in *new_addr = malloc(sizeof(struct sockaddr_in));
			bzero(new_addr, sizeof(struct sockaddr_in));
			int size;
			
			int *new_socket = malloc(4);
			bzero(new_socket, 4);
			*new_socket = accept(tcp_socket, (struct sockaddr *)new_addr, &size);
			
			if(*new_socket < 0)
			{
				perror("new_socket");
				return 0;
			}
	
			printf("%d\n", *new_socket);
			printf("%s\n", inet_ntoa(new_addr->sin_addr));
			list_add(head, new_addr, *new_socket);
			
		
			printf("%d\n", head->prev->tcp_socket);
		
			//pthread_create(&tid, NULL, func, head->prev);
			
			//linklist pos = head->prev;
			
			// for(linklist tmp = head->next; tmp != head; tmp = tmp->next)
			// {
				
				// printf("tmp:%s\n",inet_ntoa(tmp->addr.sin_addr));
				// if(strcmp(inet_ntoa(tmp->addr.sin_addr),inet_ntoa(pos->addr.sin_addr)) == 0 && tmp->tcp_socket != pos->tcp_socket)
				// {	
					// list_del(tmp);
				// }
			// }
			
		}
		/*
		for(linklist tmp = head->next; tmp != head; tmp = tmp->next)
		{
			linklist pos = head->prev;
			//printf("tmp:%s\n",inet_ntoa(tmp->addr.sin_addr));
			if(strcmp(inet_ntoa(tmp->addr.sin_addr),inet_ntoa(pos->addr.sin_addr)) == 0 && tmp->tcp_socket != pos->tcp_socket)
			{	
				list_del(tmp);
			}
		}
		*/
		
		
		if(FD_ISSET(0,&set))
		{
			char buf[100];
			scanf("%s", buf);
			strcpy(announcement,buf);
			if(strcmp(buf, "exit") == 0)
			{
				close(tcp_socket);
				for(linklist pos = head->next; pos != head; pos = pos->next)
				{
					close(pos->tcp_socket);
				}
				return 0;
			}
			
			linklist tmp = head->next;
			
			for(;tmp != head; tmp = tmp->next)
			{
				if(tmp->down_file == 0 && tmp->up_file == 0)	//防止下载和上传被冲到
					write(tmp->tcp_socket, buf, strlen(buf));
			}
		
		}
		
		
		
		
		for(linklist tmp = head->next; tmp != head; tmp = tmp->next)			//查看消息
		{
			
			if(FD_ISSET(tmp->tcp_socket,&set) && tmp->down_file == 0 && tmp->up_file == 0) //查看消息
			{
				char buf[1024] = {0};
				int size = read(tmp->tcp_socket, buf, 1024);
				if(size <= 0)
				{
						printf("客户端已经掉线了\n");
						
						//删除结点 
						linklist del = tmp;
						tmp = tmp->prev;
						del->prev->next = del->next;  
						del->next->prev = del->prev;  
						del->next = NULL; 
						del->prev = NULL;  
						close(del->tcp_socket);
						free(del); 
				}
				
				else
				{
					if(strcmp(buf,"1") == 0 && tmp->talk == 0) // 获取小区列表
					{
						bzero(buf, sizeof(buf));
						int i=1;
						printf("获取列表\n");
						char *user_list = malloc(4096);//用来存储用户
						//write(tmp->tcp_socket, buf, strlen(buf));
						for(linklist pos = head->next; pos != head; pos = pos->next)
						{
							bzero(buf, sizeof(buf));
							if(i == 1)
							{
								sprintf(user_list,"%d:%s %d   ",i++,inet_ntoa(pos->addr.sin_addr),pos->tcp_socket);
							}
							else
							{
								sprintf(buf,"%d:%s %d   ",i++,inet_ntoa(pos->addr.sin_addr),pos->tcp_socket);
								strcat(user_list,buf);
		
							}
							
						}
						write(tmp->tcp_socket, user_list, strlen(user_list));
					}
					else if(strcmp(buf,"2") == 0 && tmp->talk == 0)		//选择聊天
					{
						tmp->talk = 1;
						bzero(buf, sizeof(buf));
						int i=1;
						printf("获取列表\n");
						char *user_list = malloc(4096);//用来存储用户
						//write(tmp->tcp_socket, buf, strlen(buf));
						for(linklist pos = head->next; pos != head; pos = pos->next)
						{
							bzero(buf, sizeof(buf));
							if(i == 1)
							{
								sprintf(user_list,"%d:%s %d   ",i++,inet_ntoa(pos->addr.sin_addr),pos->tcp_socket);
							}
							else
							{
								sprintf(buf,"%d:%s %d   ",i++,inet_ntoa(pos->addr.sin_addr),pos->tcp_socket);
								strcat(user_list,buf);
		
							}
							
						}
						write(tmp->tcp_socket, user_list, strlen(user_list));
					}
					else if(strcmp(buf,"3") == 0 && tmp->talk == 0) //获取天气
					{
							pthread_t tid;
							pthread_create(&tid, NULL, weather, tmp);
					}
					
					else if(strcmp(buf, "4") == 0 && tmp->talk == 0) //接收文件
					{
							tmp->up_file = 1;
							pthread_t tid;
							pthread_create(&tid, NULL, recvfile, tmp);
					}
					else if(strcmp(buf, "5") == 0 && tmp->talk == 0) //发送文件
					{
							tmp->down_file = 1;
							DIR *dp = opendir(".");
							if(dp == NULL)
							{
								printf("目录不存在\n");
								tmp->down_file = 0;
								
								char *talk_buf = malloc(1024);
								tmp->other = 0;
								tmp->talk = 0;
								strcpy(talk_buf, "没有这个文件");
								write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
								printf("talk_buf:%s\n", talk_buf);
								free(talk_buf);	
	
								
							}
							
							else{
									struct dirent *ep = NULL;	
									char *file_name_sum = malloc(4096); //	收集服务器里的文件名
									bzero(file_name_sum, 4096);
									int i=0;
									while(1)	//查看文件
									{
										ep = readdir(dp);
										if(ep == NULL)
											break;
									
										if(strcmp(ep->d_name,".") == 0 || strcmp(ep->d_name,"..") == 0)
										{
											continue;
										}
										
										
										struct stat buf;
										bzero(&buf, sizeof(struct stat));
										stat(ep->d_name, &buf);
										if(S_ISREG(buf.st_mode))  //判断是否为普通文件
										{
											i++;
											if(i == 1)
											{
												
												sprintf(file_name_sum, "%s----", ep->d_name);
												
											}
											else
											{
												char *p = malloc(4096);
												strcpy(p,file_name_sum);
												sprintf(file_name_sum, "%s%s----",p,ep->d_name);
												free(p);
											}
										}
									}
									write(tmp->tcp_socket, file_name_sum, 4096);
									pthread_t tid;
									pthread_create(&tid, NULL, sendfile, tmp);
							}
							
							
							
							
							
							
							
							
					}
					else if(strcmp(buf, "6") == 0 && tmp->talk == 0) //发送文件
					{
						write(tmp->tcp_socket, announcement, sizeof(announcement));
					}
					
					
					else if(tmp->talk == 1)	//聊天消息
					{
						if(strcmp(buf,"exit") == 0)	//退出聊天
						{
								char *talk_buf = malloc(1024);
								tmp->other = 0;
								tmp->talk = 0;
								strcpy(talk_buf, "退出聊天!");
								write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
								printf("talk_buf:%s\n", talk_buf);
								free(talk_buf);	
								
						}
						else if(tmp->other == 0)		//赋予聊天对象
						{
							
								tmp->other = atoi(buf);
								
								if(strcmp(buf,"exit") == 0)	//退出聊天
								{
									char *talk_buf = malloc(1024);
									tmp->other = 0;
									tmp->talk = 0;
									strcpy(talk_buf, "退出聊天!");
									write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
									printf("talk_buf:%s\n", talk_buf);
									free(talk_buf);	
								
								}
								
								else
								{
								
								
									for(linklist pos = head->next; pos != head; pos = pos->next)
									{
										
										if(tmp->other == pos->tcp_socket)
										{
											if(tmp->tcp_socket == pos->tcp_socket)
											{
												char *talk_buf = malloc(1024);
												tmp->other = 0;
												tmp->talk = 0;
												strcpy(talk_buf, "不要和自己聊!");
												write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
												printf("talk_buf:%s\n", talk_buf);
												free(talk_buf);	
												break;
											}
											char *talk_buf = malloc(1024);
											strcpy(talk_buf, "此人在线!");
											write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
											//printf("talk_buf:%s\n", talk_buf);
											free(talk_buf);	
											break;
										}
										if(pos->next == head)
										{
											char *talk_buf = malloc(1024);
											tmp->other = 0;
											tmp->talk = 0;
											strcpy(talk_buf, "此人不在线!");
											write(tmp->tcp_socket, talk_buf, strlen(talk_buf));
											printf("talk_buf:%s\n", talk_buf);
											free(talk_buf);	
										}
									}		
								}									
						}

						else
						{
							char *talk_buf = malloc(1024);
							if(strcmp(buf,"gameover") == 0)
							{
								printf("客户端已经掉线了\n");
						
								//删除结点 
								linklist del = tmp;
								tmp = tmp->prev;
								del->prev->next = del->next;  
								del->next->prev = del->prev;  
								del->next = NULL; 
								del->prev = NULL;  
								close(del->tcp_socket);
								free(del); 
							}
							else{
							
									for(linklist pos = head->next; pos != head; pos = pos->next)
									{
										
										if(pos->tcp_socket == tmp->other)
										{
											
											sprintf(talk_buf,"%s:%s",inet_ntoa(tmp->addr.sin_addr),buf);
											write(pos->tcp_socket, talk_buf, strlen(talk_buf));
											printf("talk_buf:%s\n", talk_buf);
											
										}
									
									}

									free(talk_buf);	
								}
						}
					}
				}
				
			}
			
		}
		
	}
	
	
}
	